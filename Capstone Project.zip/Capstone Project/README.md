### Project Title: Predict Volume of Traffic on a given day for a given City

**Author**
Faiyad A Shayk

#### Executive summary

OVERVIEW

Inspired by a project a friend of mine in Civil Engineering Department Illinois Institute of Technology, Chicago, did it for "city of chicago" in 2006 to help improve infrastructure and traffic flow.

Goals:
1. Traffic Signal Optimization: Predict traffic volume to optimize traffic signal timing and minimize congestion
2. Real-time Traffic Management: Alert drivers to traffic conditions along their preferred route
3. Emergency Preparedness: Estimate traffic flow in the event of emergencies or disaste
4. Travel Time Estimation: Provide accurate travel time predictions to commuters and travel
5. Support Infrastructure Development: Expansion of roads, parking lots development

#### Rationale
Why should anyone care about this question?

Traffic congestion leads to significant productivity losses, costing the U.S. economy billions annually, with drivers losing an average of 43 hours to traffic jams, equivalent to a full work week, and costing $771 in lost time and productivity. 
Here's a more detailed breakdown of the impact of traffic congestion on productivity:

Economic Impact:
Lost Time and Productivity:
The INRIX 2024 Global Traffic Scorecard found that the average U.S. driver lost 43 hours to traffic jams, costing $771 in lost time and productivity. 

Nationwide Costs:
This translates to over four billion hours lost nationwide, costing the U.S. economy $74 billion in lost time. 
excluding Impact on Businesses, Opportunity Costs, Impact on Supply Chains, Impact on Government Services:

Individual Impact:
Increased Commute Time, Stress and Frustration, Delayed Meetings and Appointments, Reduced Access to Jobs and Opportunities. 


#### Research Question
What are you trying to answer?

1. Traffic Signal Optimization: Predict traffic volume to optimize traffic signal timing and minimize congestion
2. Real-time Traffic Management: Alert drivers to traffic conditions along their preferred route
3. Emergency Preparedness: Estimate traffic flow in the event of emergencies or disaste
4. Travel Time Estimation: Provide accurate travel time predictions to commuters and travel
5. Support Infrastructure Development: Expansion of roads, parking lots development

#### Data Sources
What data will you use to answer you question?

Any typical large busy city data like City of Chicago or New York etc.

#### Methodology
What methods are you using to answer the question?

Regressors and Boosters for modeling and prediction.

#### Results
What did your research find?

RandomForestRegressors and GradientBoostRegressors are being used in this area so trying to get a sence of how to model and provide solution.

#### Next steps
What suggestions do you have for next steps?

Plan of working the base model first and build the regressors, tune up and provide solution.

#### Outline of project

- [Link to notebook 1]()
- [Link to notebook 2]()
- [Link to notebook 3]()


##### Contact and Further Information
520-637-3319
shaifiy@gmail.com