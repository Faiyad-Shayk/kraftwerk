################################################################################################################################
###                                      Predict Volume of Traffic on a given day for a given City                           ###
###############################################Inital Investigation#############################################################
1. Business Understanding Phase CRISP-DM Methodology - Part of Exploratory Data Analysis
	Determine Business Objectives
     	Assess Situation
     	Costs and Benefits
     	Determine Data Mining Goals
     	Produce Project Plan

2. Data Understanding Phase CRISP-DM Methodology - Part of Exploratory Data Analysis
     	Collect Initial Data
     	Describe Data
     	Explore Data
     	Verify Data Quality

3. Data Preparation Phase CRISP-DM Methodology - Part of Final Report
     	Data Set
     	Select Data
     	Clean Data
     	Construct Data
     	Integrate Data
     	Format Data

4. Modeling Phase CRISP-DM Methodology - Part of Final Report
	Select Modeling Technique
	Generate Test Design
	Build Model
	Assess Model

5. Deployment Phase CRISP-DM Methodology - Part of Final Report
	Plan Deployment
	Plan Monitoring and Maintenance
	Final Report
	Review Project
################################################################################################################################
###                                       Predict Volume of Traffic on a given day for a given City                          ###
################################################################################################################################


