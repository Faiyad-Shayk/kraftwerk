################################################################################################################################
###                         Practical Application Assignment 11.1: What Drives the Price of a Car?                           ###
###############################################Inital Investigation#############################################################
1. Business Understanding Phase CRISP-DM Methodology
	Determine Business Objectives
     	Assess Situation
     	Costs and Benefits
     	Determine Data Mining Goals
     	Produce Project Plan

2. Data Understanding Phase CRISP-DM Methodology
     	Collect Initial Data
     	Describe Data
     	Explore Data
     	Verify Data Quality

3. Data Preparation Phase CRISP-DM Methodology
     	Data Set
     	Select Data
     	Clean Data
     	Construct Data
     	Integrate Data
     	Format Data

4. Modeling Phase CRISP-DM Methodology
	Select Modeling Technique
	Generate Test Design
	Build Model
	Assess Model

5. Deployment Phase CRISP-DM Methodology
	Plan Deployment
	Plan Monitoring and Maintenance
	Final Report
	Review Project
################################################################################################################################
###                                           Practical Application Assignment 11.1 End                                      ###
################################################################################################################################


